angular.module('product', [])

.controller('productCtrl',
            function ($scope) {
                $scope.title = 'Product'
            });