angular.module('overview', [])

.controller('overviewCtrl',
            function ($scope) {
                $scope.title = 'Overview'
            });