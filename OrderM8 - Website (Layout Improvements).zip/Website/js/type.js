angular.module('type', [])

.controller('typeCtrl',
            function ($scope) {
                $scope.title = 'Type'
            });