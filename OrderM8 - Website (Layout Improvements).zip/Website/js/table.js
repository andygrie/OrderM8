angular.module('table', [])

.controller('tableCtrl',
            function ($scope) {
                $scope.title = 'Table'
            });