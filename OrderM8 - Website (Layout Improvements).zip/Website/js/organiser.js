angular.module('organiser', [])

.controller('organiserCtrl',
            function ($scope) {
                $scope.title = 'Organiser'
            });