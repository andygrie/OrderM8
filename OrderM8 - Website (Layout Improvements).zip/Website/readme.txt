Funktioniert mit Firefox

Chrome:
(Zugriff auf lokale Files erlauben) :
cmd - "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --disable-web-security --user-data-dir="D:\chrome"