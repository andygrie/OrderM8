﻿angular.module('waiter', [])

.controller('waiterCtrl',
            function ($scope) {
                $scope.title = 'Waiter'
            });