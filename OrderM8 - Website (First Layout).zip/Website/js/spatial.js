angular.module('spatial', [])

.controller('spatialCtrl',
            function ($scope) {
                $scope.title = 'Spatial'
            });